"""AI SEO Audit Team package."""

from .agent import root_agent

__all__ = ["root_agent"]